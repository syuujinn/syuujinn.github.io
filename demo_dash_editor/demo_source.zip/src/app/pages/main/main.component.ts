import { Component, ElementRef, NgZone, ViewChild, OnInit, AfterViewChecked, ViewChildren, QueryList } from '@angular/core';
import { Application, Sprite, Texture, Point } from 'pixi.js';
import { Square, Cell } from '../../libs/Square';
// import { RadialGauge, } from '@biacsics/ng-canvas-gauges';
import { RadialGauge, BaseGauge } from 'canvas-gauges';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit, AfterViewChecked {

  private _sprite: Sprite = new Sprite();

  public get scanvas(): Sprite { return this._sprite; }
  public set scanvas(val: Sprite) { this._sprite = val; }

  private test = new Subject<boolean>();
  public test$ = this.test.asObservable();

  private _test_value: number = 200;
  public get test_value(): number { return this._test_value; }
  public set test_value(val: number) { this._test_value = val; }

  private _gu_options: any = {};
  public get gu_options(): any { return this._gu_options; }
  public set gu_options(val: any) { this._gu_options = val; }

  private _gu_options2: any = {};
  public get gu_options2(): any { return this._gu_options2; }
  public set gu_options2(val: any) { this._gu_options2 = val; }

  private _main_app: Application = new Application({ background: '#1099bb' });
  private _option: any = {};
  private _frames: any = {};

  public get frames(): any { return this._frames; }
  public set frames(val: any) { this._frames = val; }

  public get option(): any { return this._option; }
  public set option(val: any) { this._option = val; }

  public get main_app(): Application { return this._main_app; }
  public set main_app(val: Application) { this._main_app = val; }

  @ViewChild("conatiner", { static: true }) child!: RadialGauge;
  @ViewChild("canvas2", { static: true }) canvas!: ElementRef;


  @ViewChild("drawconatiner", { static: true }) draw_conatiner!: ElementRef;

  private _gauges: any[] = [];

  public get gauges(): any[] { return this._gauges; }
  public set gauges(val: any[]) { this._gauges = val; }

  droppedData: string = "";


  private _pos_mouse: Point = new Point();

  public get pos_mouse(): Point { return this._pos_mouse; }
  public set pos_mouse(val: Point) { this._pos_mouse = val; }


  @ViewChildren("item") itemsElement!: QueryList<any>;
  @ViewChild("test", { static: true }) test2!: ElementRef;
  @ViewChild("test2", { static: true }) test3!: ElementRef;

  constructor(private elementRef: ElementRef, private ngZone: NgZone) {


    

    this._gu_options =
    {
      width: "300",
      height: "300",
      units: "MPH",
      minValue: 0,
      startAngle: 60,
      ticksAngle: 240,
      valueBox: false,
      maxValue: "220",
      majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220],
      minorTicks: 2,
      strokeTicks: true,
      highlights: [
        { from: 160, to: 220, color: "rgba(200, 50, 50, .75)" }
      ],
      colorPlate: "#fff",
      borderShadowWidth: 0,
      borders: false,
      needleType: "arrow",
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 500,
      animationRule: "linear",
      // animateOnInit: true,
      // renderTo: "v",
      listeners: {
        value: function (newValue: any, oldValue: any) {
          // do something
          // console.log(newValue);
        },
        render: [
          () => {

            this._dtext.update();
          }

        ]
      }

    };
    this._gu_options2=
    {
      width: "100",
      height: "100",
      units: "MPH",
      minValue: 0,
      startAngle: 60,
      ticksAngle: 240,
      valueBox: false,
      maxValue: "220",
      majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220],
      minorTicks: 2,
      strokeTicks: true,
      highlights: [
        { from: 160, to: 220, color: "rgba(200, 50, 50, .75)" }
      ],
      colorPlate: "#fff",
      borderShadowWidth: 0,
      borders: false,
      needleType: "arrow",
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 500,
      animationRule: "linear",
      // animateOnInit: true,
      listeners: {
        value: function (newValue: any, oldValue: any) {
          // do something
          // console.log(newValue);
        },
        render: [
          () => {

            this._dtext.update();
          }

        ]
      }

    };

    this._gauges.push({ val: "00" });
    this._gauges.push({ val: "00" });
    this._gauges.push({ val: "00" });


  }

  private _dtext: Texture = Texture.WHITE;
  public get dtext(): Texture { return this._dtext; }
  public set dtext(val: Texture) { this._dtext = val; }

  public drop(event: any) {
    console.log(event);
    console.log("x");
    var vo = {
      width: 300,
      height: 300,
      units: "MPH",
      minValue: 0,
      startAngle: 60,
      ticksAngle: 240,
      valueBox: false,
      maxValue: 220,
      majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220],
      minorTicks: 2,
      strokeTicks: true,
      highlights: [
        { from: 160, to: 220, color: "rgba(200, 50, 50, .75)" }
      ],
      colorPlate: "#fff",
      borderShadowWidth: 0,
      borders: false,
      needleType: "arrow",
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 500,
      animationRule: "linear",
      // animateOnInit: true,
      // renderTo: "vv",
      // listeners: {
      //   value: function (newValue: any, oldValue: any) {
      //     // do something
      //     // console.log(newValue);
      //   },
      //   render: [
      //     () => {

      //       this._dtext.update();
      //     }

      //   ]
      // }
    };
    console.log( this.child.canvas);
    // var rg = new RadialGauge(vo);
    // rg.
    // rg.draw();

    // var rg = new RadialGauge(this.test2, this.ngZone);
    // rg.value = 200;
    // rg.update(vo);

    // console.log(2);
    // <canvas data-type="radial-gauge"
    // data-min-value="0"
    // data-max-value="360"
    // data-major-ticks="N,NE,E,SE,S,SW,W,NW,N"
    // data-minor-ticks="22"
    // data-ticks-angle="360"
    // data-start-angle="180"
    // data-stroke-ticks="false"
    // data-highlights="false"
    // data-color-plate="#222"
    // data-color-major-ticks="#f5f5f5"
    // data-color-minor-ticks="#ddd"
    // data-color-numbers="#ccc"
    // data-color-needle="rgba(240, 128, 128, 1)"
    // data-color-needle-end="rgba(255, 160, 122, .9)"
    // data-value-box="false"
    // data-value-text-shadow="false"
    // data-color-circle-inner="#fff"
    // data-color-needle-circle-outer="#ccc"
    // data-needle-circle-size="15"
    // data-needle-circle-outer="false"
    // data-animation-rule="linear"
    // data-needle-type="line"
    // data-needle-start="75"
    // data-needle-end="99"
    // data-needle-width="3"
    // data-borders="true"
    // data-border-inner-width="0"
    // data-border-middle-width="0"
    // data-border-outer-width="10"
    // data-color-border-outer="#ccc"
    // data-color-border-outer-end="#ccc"
    // data-color-needle-shadow-down="#222"
    // data-border-shadow-width="0"
    // data-animation-duration="1500"
// ></canvas>
// var gauge = new RadialGauge({
//     renderTo: 'canvas-id',
//     minValue: 0,
//     maxValue: 360,
//     majorTicks: [
//         "N",
//         "NE",
//         "E",
//         "SE",
//         "S",
//         "SW",
//         "W",
//         "NW",
//         "N"
//     ],
//     minorTicks: 22,
//     ticksAngle: 360,
//     startAngle: 180,
//     strokeTicks: false,
//     highlights: false,
//     colorPlate: "#222",
//     colorMajorTicks: "#f5f5f5",
//     colorMinorTicks: "#ddd",
//     colorNumbers: "#ccc",
//     colorNeedle: "rgba(240, 128, 128, 1)",
//     colorNeedleEnd: "rgba(255, 160, 122, .9)",
//     valueBox: false,
//     valueTextShadow: false,
//     colorCircleInner: "#fff",
//     colorNeedleCircleOuter: "#ccc",
//     needleCircleSize: 15,
//     needleCircleOuter: false,
//     animationRule: "linear",
//     needleType: "line",
//     needleStart: 75,
//     needleEnd: 99,
//     needleWidth: 3,
//     borders: true,
//     borderInnerWidth: 0,
//     borderMiddleWidth: 0,
//     borderOuterWidth: 10,
//     colorBorderOuter: "#ccc",
//     colorBorderOuterEnd: "#ccc",
//     colorNeedleShadowDown: "#222",
//     borderShadowWidth: 0,
//     animationDuration: 1500
// }).draw();

  }

  dragEnd(event: any) {
    console.log('Element was dragged', event);
  }

  demox(event: any) {
    console.log(event);

  }

  ngOnInit(): void {
    // this.child.      

    setInterval(() => {
      this._test_value = ~~(Math.random() * 150);

      //   var destinationContext = this.child.nativeElement.getContext("2d");
      //   this.child.nativeElement.width = 300;
      //   this.child.nativeElement.height = 300;
      //   destinationContext.drawImage(this.canvas.nativeElement, 0, 0);
      // //   this._main_app.stage.removeChildren();
      //   this._sprite.texture =  Texture.from(this.child.nativeElement.toDataURL('image/png'));
      //   this.main_app.render();
    }, 1500);

    setInterval(() => {

      // this._sprite.texture =  Texture.from(this.child.nativeElement);
    }, 30);


    // var dom = document.createElement("radial-gauge");
    var dom = document.createElement("canvas");

    var rg =new RadialGauge( Object.assign(this._gu_options, { renderTo: this.test3.nativeElement }));

    
    this.draw_conatiner.nativeElement.appendChild(dom);

    rg.draw()

    this._test_value = ~~(Math.random() * 200);

    this.loadOption();
    this.draw_conatiner.nativeElement.appendChild(this._main_app.view);

    this._main_app.stage.interactive = true;

    this._main_app.stage.on('pointermove', (event: any) => { this._pos_mouse = event.global; });




    this._dtext = Texture.from(this.canvas.nativeElement);
    this._sprite = Sprite.from(this._dtext);
    // this._sprite.width = 300;
    // this._sprite.height = 300;
    this._sprite.anchor.set(0.5, 0.5);
    this._sprite.x = 350;
    this._sprite.y = 350;
    this._sprite.interactive = true;
    this._sprite.cursor = "pointer";
    console.log(this._dtext);
    this._main_app.stage.on('pointerup', () => { this.onDragEnd(); });
    this._main_app.stage.on('pointerdown', () => { this.onDragStart(); });
    this._main_app.stage.on('pointerupoutside', () => { this.onDragEnd(); });

    this._main_app.stage.addChild(this._sprite);

    this._dtext = Texture.from(this.canvas.nativeElement);

  }

  private onDragMove(event: any, ta: any) {
    // if (dragTarget) {
    // dragTarget.parent.toLocal(event.global, null, dragTarget.position);
    // }
    ta.parent.toLocal(event.global, null, ta.position);

    // this._sprite.texture =  Texture.from(this.child.nativeElement);
  }

  private onDragStart() {

    this._sprite.width = 280;
    this._sprite.height = 280;
    this._sprite.alpha = 0.8;

    this._main_app.stage.on('pointermove', (event: any) => { this.onDragMove(event, this._sprite) });
  }

  private onDragEnd() {

    this._sprite.width = 300;
    this._sprite.height = 300;
    this._sprite.alpha = 1;
    this._main_app.stage.off('pointermove');
  }

  private loadOption() {

    // let o = localStorage["option"] != undefined ? JSON.parse(localStorage["option"]) : {};
    let keys = Object.keys(localStorage);
    this._option = {
      window: {
        width: 600,
        height: 800,
        backgroundColor: 0x7F7F7F
      },
      frames: {
        area: { x: 0, y: 0, width: 600, height: 800, nw: 34, nh: 48 },
        bumper: { x: 75, y: 200, width: 400, height: 300, nw: 5, nh: 5 },
        bat2: { x: 400, y: 600, width: 150, height: 30, nw: 5, nh: 1, angle: -.76 },
        bat3: { x: 150, y: 600, width: 150, height: 30, nw: 5, nh: 1, angle: .76 },
        r1: { x: 175, y: 150, width: 100, height: 20, nw: 5, nh: 1 },
        r2: { x: 375, y: 150, width: 100, height: 20, nw: 5, nh: 1 },
        r3: { x: 275, y: 550, width: 100, height: 20, nw: 5, nh: 1 },
      },
      limit: {
        numBall: 30,
        yLimit: 900
      },
      size: {

        ball: 15,
        bumper: 30
      },
      urls: {
        svg: './assets/img/image2vector.svg',
        map: './assets/map.json'
      },
      debug: {
        map: true,
        num: 0,
        grid: { bumper: false, area: false }
      }
    };
  }
  ngAfterViewChecked() {

    this.itemsElement.map((e) => {
      console.log("itemElement", e.name);
    });
  }
  private createFrame() {

    const { frames } = this._option;
    this._frames = {};
    Object.keys(frames).forEach((key) => {

      const frame = frames[key];
      const { x, y, width, height, nw, nh } = frame;
      this._frames[key] = new Square({ x, y, width, height }, nw, nh);

    });

    const f: Square = this._frames['area'];
    // for (let y = 0; y < f.ncy; y++) {
    //   this.map.push(Array.call(null, ...Array(f.ncx)).fill(0));
    // }

  }

}
