import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { Application, Container, Sprite, Texture, Point, Rectangle, Graphics } from 'pixi.js';
import { Mygauge } from '../libs/mygaue';
import { Square } from '../libs/Square';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss']
})
export class DemoComponent implements OnInit {

  private _application!: Application;
  private _option: any = {};
  private _pos_frame_mouse: Point = new Point();
  private _pos_real_mouse: Point = new Point();

  private _pos_last_frame_mouse: Point = new Point();
  
  private _view_container!: any;
  private _gauges: Mygauge[] = [];
  private _status: any = {};
  private _gs_frame: Graphics = new Graphics();
  private _gs_main: Graphics = new Graphics();

  private _stages: any = {};
  private _freams: any = {};

  private _track_point: Point[] = [];

  public get pos_real_mouse(): Point { return this._pos_real_mouse; }
  public set pos_real_mouse(val: Point) { this._pos_real_mouse = val; }

  public get track_point(): Point[] { return this._track_point; }
  public set track_point(val: Point[]) { this._track_point = val; }

  public get gs_main(): Graphics { return this._gs_main; }
  public set gs_main(val: Graphics) { this._gs_main = val; }

  public get gs_frame(): Graphics { return this._gs_frame; }
  public set gs_frame(val: Graphics) { this._gs_frame = val; }

  public get status(): any { return this._status; }
  public set status(val: any) { this._status = val; }

  public get freams(): any { return this._freams; }
  public set freams(val: any) { this._freams = val; }

  public get stages(): any { return this._stages; }
  public set stages(val: any) { this._stages = val; }

  public get gauges(): Mygauge[] { return this._gauges; }
  public set gauges(val: Mygauge[]) { this._gauges = val; }

  public get view_container(): any { return this._view_container; }
  public set view_container(val: any) { this._view_container = val; }
  public get pos_frame_mouse(): Point { return this._pos_frame_mouse; }
  public set pos_frame_mouse(val: Point) { this._pos_frame_mouse = val; }
  
  public get pos_last_frame_mouse(): Point{ return this._pos_last_frame_mouse; }
  public set pos_last_frame_mouse(val: Point){ this._pos_last_frame_mouse = val; }

  public get option(): any { return this._option; }
  public set option(val: any) { this._option = val; }

  public get application(): Application { return this._application; }
  public set application(val: Application) { this._application = val; }

  @ViewChild("container", { static: true }) _container!: ElementRef;

  constructor() {

    this._status["system_time"] = Date.now();
    this._status["interactive_time"] = 0;
    this._status["last_time"] = Date.now();
    this._status["last_time2"] = Date.now();
    this._status["frames"] = {};
    this._status["pointerdown"] = false;

  }

  ngOnInit(): void {
    this.loadOption();
    this._application = new Application(this._option.window);
    this._container.nativeElement.appendChild(this._application.view);

    // this._stages["main"] = this._application.stage;
    // this._stages["main"]

    this._view_container = this._application.stage;  //new Sprite();

    this.createStage("frame", 0, 0, this._option.window.width, this._option.window.height);
    this.createStage("main", 0, 0, this._option.window.width, this._option.window.height);

    this._stages["main"].interactive = true;
    this._stages["main"].cursor = "pointer";
    // this._stages["main"].width = this._option.window.width;
    // this._stages["main"].height = this._option.window.height;

    this._stages["main"].on('pointerdown', ()=>{ this._status["pointerdown"] = true; });
    this._stages["main"].on('pointerup',  ()=>{ this._status["pointerdown"] = false;});    
    this._stages["main"].on('pointermove', (
      event: any) => {

      let frame: Square = this._freams["main"];
      var temp = new Point();
      let cell = frame.getCellByPosition(event.global.x, event.global.y)


      if (this._pos_frame_mouse.x != 0 && this._pos_frame_mouse.y != 0) {
       this._pos_last_frame_mouse.set( this._pos_frame_mouse.x, this._pos_frame_mouse.y);
      }

      if (cell)
        this._pos_frame_mouse.set(cell.center.x, cell.center.y);


      if (this._pos_real_mouse.x != 0 && this._pos_real_mouse.y != 0) {
        temp = new Point(this._pos_real_mouse.x, this._pos_real_mouse.y);
      }
      this._pos_real_mouse.set(event.global.x, event.global.y);

      // if (temp.x != 0 && temp.y != 0) {
      //   let rp = this.cp(this._pos_real_mouse, temp);
      //   for (let i in rp) {
      //     this._track_point.push(new Point( rp[i].x, rp[i].y));
      //     if (this._track_point.length > 60)
      //       this._track_point.shift();
      //   }
      // }

    });

    this._stages["main"].addChild(this.gs_main);
    this._stages["frame"].addChild(this._gs_frame);
    // this._application.stage.addChild(this._view_container);
    this._application.ticker.add(() => { this.tick(); })
    // this._application.ticker.speed = 120;
  }


  private cp(np: Point, lp: Point) {
    var x = np.x;
    var y = np.y;

    var res = [];

    // Calculate the distance between the previous and current mouse positions
    var dx = x - lp.x;
    var dy = y - lp.y;
    var distance = Math.sqrt(dx * dx + dy * dy);

    // Interpolate a number of points between the previous and current mouse positions
    var numPoints = Math.floor(distance / 50);
    for (var i = 0; i < numPoints; i++) {
      var t = i / numPoints;
      var interpolatedX = lp.x + t * dx;
      var interpolatedY = lp.y + t * dy;

      // Use a triangle function to smooth out the curve between the points
      var smoothness = 5;
      var triangleY = smoothness * Math.abs(interpolatedX - lp.x) * (interpolatedY > lp.y ? 1 : -1);

      res.push(new Point(interpolatedX, interpolatedY + triangleY));
    }
    return res;
  }

  private createStage(name: string, x: number, y: number, width: number, height: number) {
    this._freams[name] = new Square(new Rectangle(x, y, width, height), 10, 8);
    this._stages[name] = new Container();
    this._status["frames"][name] = true;

    this._view_container.addChild(this._stages[name]);
  }

  private loadOption() {

    // let o = localStorage["option"] != undefined ? JSON.parse(localStorage["option"]) : {};
    let keys = Object.keys(localStorage);
    this._option = {
      window: {
        width: 800,
        height: 640,
        backgroundColor: 0x7F7F7F
      },
      frames: {
        area: { x: 0, y: 0, width: 600, height: 800, nw: 34, nh: 48 },
        bumper: { x: 75, y: 200, width: 400, height: 300, nw: 5, nh: 5 },
        bat2: { x: 400, y: 600, width: 150, height: 30, nw: 5, nh: 1, angle: -.76 },
        bat3: { x: 150, y: 600, width: 150, height: 30, nw: 5, nh: 1, angle: .76 },
        r1: { x: 175, y: 150, width: 100, height: 20, nw: 5, nh: 1 },
        r2: { x: 375, y: 150, width: 100, height: 20, nw: 5, nh: 1 },
        r3: { x: 275, y: 550, width: 100, height: 20, nw: 5, nh: 1 },
      },
      debug: {
        map: true,
        num: 0,
        grid: { bumper: false, area: false }
      }
    };
  }

  private tick() {

    let sd = Date.now();
    this._status["update_time"] = Date.now();
    this._status["gauges"] = this._gauges.length;

    this._track_point.push(new Point( this._pos_real_mouse.x, this._pos_real_mouse.y));
    if (this._track_point.length > 20)
      this._track_point.shift();

    this._gs_frame.clear();
    this._gs_main.clear();

    this._gs_main.beginFill(0xFFFFFF, .2);
    this._gs_main.drawRect(0, 0, this._option.window.width, this._option.window.height);
    this._gs_main.endFill();
    for (let key in this._freams) {
      // console.log( this._status["frames"][key] );
      if (this._status["frames"][key])
        this.createGrid(this._freams[key], 0xFFFFFF);
    }

    for (let ip = 0; ip < this._track_point.length; ip++) {
      // let p1 = this._track_point[ip - 2];
      // let p2 = this._track_point[ip - 1];
      let p3 = this._track_point[ip];
      let ap = ip / 20;
      let r = 5 * (1 - ap );
      // this._gs_main.lineStyle(1, 0xFF0000, 1);
      this._gs_main.beginFill(0xFF0000, ap);
      this._gs_main.drawCircle( p3.x, p3.y, r);
      this._gs_main.endFill();

    }


    let vx = this._pos_frame_mouse.x - this._pos_last_frame_mouse.x;
    let vy = this._pos_frame_mouse.y - this._pos_last_frame_mouse.y;
    
    this._gauges.forEach((g: Mygauge) => {

      // temp_g.push({x: g.x, y: g.y, source: g.source, type: "gauge", other: "..." });

      g.update();
      if (g.bActivated && this._status["pointerdown"]) {
        // g.x += vx;
        // g.y += vy;
        g.x = this._pos_frame_mouse.x;
        g.y = this._pos_frame_mouse.y;
      }

    });

    this._status["interactive_time"] = Date.now() - sd;
    this._status["last_time2"] = Date.now() - this._status["last_time"];
    this._status["last_time"] = Date.now();


    // console.log(this._track_point[0 ], this._track_point[this._track_point.length -1 ]);
  }

  private createGrid(frame: Square, color: number) {

    const cell = frame.first;
    this.gs_frame.lineStyle(1, color, .6);
    // console.log(frame);
    if (cell) {
      for (let w = 0; w <= frame.ncx; w++) {
        this.gs_frame.moveTo(cell.x + w * cell.width, cell.y);
        this.gs_frame.lineTo(cell.x + w * cell.width, cell.y + frame.range.height);
      }
      for (let h = 0; h <= frame.ncy; h++) {
        this.gs_frame.moveTo(cell.x, cell.y + h * cell.height);
        this.gs_frame.lineTo(cell.x + frame.range.width, cell.y + h * cell.height);
      }
    }
  }


  public drop(event: any, number: number) {

    var mg = new Mygauge(100, number);
    mg.x = this._pos_frame_mouse.x;
    mg.y = this._pos_frame_mouse.y;
    this._stages["main"].addChild(mg);

    setInterval(() => {
      mg.source += (~~(Math.random() * 5) - 2);
      mg.source = Math.max(0, mg.source);
      mg.source = Math.min(220, mg.source);
      // console.log(mg.source);
    }, 16);
    this._gauges.push(mg);

  }

  public dragEnd(event: any, number: number) {

    var mg = new Mygauge(100, number);
    mg.x = this._pos_frame_mouse.x;
    mg.y = this._pos_frame_mouse.y;
    this._stages["main"].addChild(mg);

    setInterval(() => {
      mg.source += (~~(Math.random() * 5) - 2);
      mg.source = Math.max(0, mg.source);
      mg.source = Math.min(220, mg.source);
      // console.log(mg.source);
    }, 16);
    this._gauges.push(mg);

    console.log('00', event);
  }

  public btn_click() {

  }
}
