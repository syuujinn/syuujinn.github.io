import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import {HotkeysService, Hotkey} from 'angular2-hotkeys';


@Injectable({
    providedIn: 'root'
})
export class MyMessageService {

    private _keydown: Subject<string> = new Subject<string>();
    
    public keydown$ = this._keydown.asObservable();


    public onMenuStateChange(key: string) {
        this._keydown.next(key);
    }
}

export const GlobalShotcutkey: any = {
    Copy : [ "ctrl+c" ],
    Paste : [ "ctrl+v" ],
    Group : [ "ctrl+g" ],
    Select_All : [ "ctrl+a" ]
}