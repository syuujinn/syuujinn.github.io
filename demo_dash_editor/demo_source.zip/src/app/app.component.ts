import { Component, HostListener  } from '@angular/core';
import { GlobalShotcutkey } from "./shotcutkey.service";
import { MyMessageService} from "../app/shotcutkey.service";
import {HotkeysService, Hotkey} from 'angular2-hotkeys';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'demo_d';

  constructor(private _myMessageService: MyMessageService, private _hotkeysService: HotkeysService) {
    let keys = Object.keys( GlobalShotcutkey);
    for ( let i = 0; i < keys.length; i++){
      let key = keys[i]; // GlobalShotcutkey[i];
      let skey =  GlobalShotcutkey[key];
      
      this._hotkeysService.add(new Hotkey(skey, (event: KeyboardEvent): boolean => {
        console.log(key, event);
        this._myMessageService.onMenuStateChange(key );
        return false; // Prevent bubbling
    }));
    }
    
}
  // private _b_key_ctrl: boolean = false;
  // public get b_key_ctrl(): boolean{ return this._b_key_ctrl; }
  // public set b_key_ctrl(val: boolean ){ this._b_key_ctrl = val; }

  
  // @HostListener('document:keydown', ['$event'])
  // handleKeydown(event: KeyboardEvent) {
    
  //   let ck:boolean = event.ctrlKey;
  //   let key = event.key.toLocaleUpperCase();

  //   let keys = Object.keys( GlobalShotcutkey);

  //   for ( let i = 0; i < keys.length; i++){
  //     let k : string = keys[i];
  //     let gk = GlobalShotcutkey[k];
  //     let res = true 
  //     for ( let ik = 0; ik < gk.length; ik++ ){
  //       var val =  gk[ik].toLocaleUpperCase();
  //       if ( val == "ctrl" ){
  //         res = ck && res
  //       } 
  //       else {
          
  //       }
        
  //       // else if ()
  //     }
  //   }

  // }
  
  // @HostListener('document:keyup', ['$event'])
  // handleKeyup(event: KeyboardEvent) {
    
  // }
  
}
