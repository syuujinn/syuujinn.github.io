import { Mygauge } from './mygaue';

describe('Mygaue', () => {
  it('should create an instance', () => {
    expect(new Mygauge()).toBeTruthy();
  });
});
