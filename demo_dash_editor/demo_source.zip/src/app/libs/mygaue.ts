import { Application, Sprite, Texture, Point, Graphics } from 'pixi.js';
import { RadialGauge, BaseGauge } from 'canvas-gauges';

export class Mygauge extends Sprite {

  private _gu_options: any = {};
  private _bActivated: boolean = false;
  private _bHover: boolean = false;
  private _temp_status: any = {};
  private _source: number = 0;
  private _oWdith: number = 0;
  private _oHeight: number = 0;
  private _radial_gauge!: RadialGauge;
  private _canvas_texture!: Texture;
  private _rg_canvas: any = null;
  private _graphics: Graphics = new Graphics();
  private _cell!: Sprite;

  public get cell(): Sprite { return this._cell; }
  public set cell(val: Sprite) { this._cell = val; }

  public get bHover(): boolean { return this._bHover; }
  public set bHover(val: boolean) { this._bHover = val; }

  public get graphics(): Graphics { return this._graphics; }
  public set graphics(val: Graphics) { this._graphics = val; }

  public get temp_status(): any { return this._temp_status; }
  public set temp_status(val: any) { this._temp_status = val; }

  public get source(): number { return this._source; null }
  public set source(val: number) { this._source = val; null }

  public get rg_canvas(): any { return this._rg_canvas; }
  public set rg_canvas(val: any) { this._rg_canvas = val; }

  public get canvas_texture(): Texture { return this._canvas_texture; }
  public set canvas_texture(val: Texture) { this._canvas_texture = val; }

  public get radial_gauge(): RadialGauge { return this._radial_gauge; }
  public set radial_gauge(val: RadialGauge) { this._radial_gauge = val; }

  public get oHeight(): number { return this._oHeight; }
  public set oHeight(val: number) { this._oHeight = val; }

  public get oWdith(): number { return this._oWdith; }
  public set oWdith(val: number) { this._oWdith = val; }

  public get bActivated(): boolean { return this._bActivated; }
  public set bActivated(val: boolean) { this._bActivated = val; }

  public get gu_options(): any { return this._gu_options; }
  public set gu_options(val: any) { this._gu_options = val; }

  constructor(source: number = 0, type: number = 0) {

    super();

    this.interactive = true;
    this.cursor = "pointer";
    this._source = source;

    this.on('pointerup', () => { this.onPointerup(); });
    this.on('pointerdown', () => { this.onPointerdown(); });
    this.on('pointerupoutside', () => { this.onPointerup(); });

    if (type == 0) {

      this._gu_options =
      {
        width: "300",
        height: "300",
        units: "MPH",
        minValue: 0,
        startAngle: 60,
        ticksAngle: 240,
        valueBox: false,
        maxValue: "220",
        majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220],
        minorTicks: 2,
        strokeTicks: true,
        highlights: [
          { from: 160, to: 220, color: "rgba(200, 50, 50, .75)" }
        ],
        colorPlate: "#fff",
        borderShadowWidth: 0,
        borders: false,
        needleType: "arrow",
        needleWidth: 2,
        needleCircleSize: 7,
        needleCircleOuter: true,
        needleCircleInner: false,
        animationDuration: 0,
        animationRule: "linear",
        listeners: {
          value: function (newValue: any, oldValue: any) {
          },
          render: [
            () => { }
          ]
        }
      };
    }
    else if (type == 1) {
      this._gu_options =
      {
        width: 300,
        height: 300,
        minValue: 0,
        maxValue: 360,
        majorTicks: ["N", "", "E", "", "S", "", "W", "", "N"],
        minorTicks: 10,
        ticksAngle: 360,
        startAngle: 180,
        strokeTicks: false,
        highlights: false,
        colorPlate: "#222",
        colorMajorTicks: "#f5f5f5",
        colorMinorTicks: "#ddd",
        colorNumbers: "#ccc",
        colorNeedle: "rgba(240, 128, 128, 1)",
        colorNeedleEnd: "rgba(255, 160, 122, .9)",
        numbersMargin: 2,
        fontNumbersSize: 30,
        colorNeedleShadowDown: false,
        colorNeedleCircleOuter: "#444",
        colorNeedleCircleOuterEnd: "#111",
        colorNeedleCircleInner: "#444",
        colorNeedleCircleInnerEnd: "#111",
        colorCircleInner: false,

        valueBox: false,
        valueTextShadow: false,
        needleCircleSize: 7,

        animationRule: "linear",
        needleType: "line",
        needleStart: 75,
        needleEnd: 99,
        needleWidth: 3,
        borders: true,
        borderInnerWidth: 3,
        borderMiddleWidth: 1,
        borderOuterWidth: 5,
        colorBorderInner: "#455",
        colorBorderMiddle: "#222",
        colorBorderOuter: "#888",
        colorBorderOuterEnd: "#caa",

        borderShadowWidth: 0,
        animationDuration: 1500,
        animationTarget: "plate",
        class: "gauge"
      };
    }
    else if (type == 2) {
      this._gu_options =
      {
        width: 300,
        height: 300,
        units: "RPM",
        minValue: 0,
        maxValue: 12000,
        majorTicks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        minorTicks: 0,
        strokeTicks: true,
        highlights: [
          { from: 9250, to: 11995, color: "rgba(200, 50, 50, .75)" }
        ],
        highlightsWidth: 13,
        ticksAngle: 270,
        startAngle: 0,

        valueBox: false,

        borderInnerWidth: 10,
        borderMiddleWidth: 1,
        borderOuterWidth: 5,

        colorMajorTicks: "#888",
        colorMinorTicks: "#ddd",
        colorTitle: "#eee",
        colorUnits: "#ccc",
        colorNumbers: "#bb1",
        colorPlate: "#000",
        colorPlateEnd: "#222",
        borderShadowWidth: 0,
        borders: true,
        needleType: "arrow",
        needleWidth: 2,
        needleCircleSize: 7,
        needleCircleOuter: true,
        needleCircleInner: false,
        animationDuration: 1500,
        animationRule: "linear",

        colorBorderOuter: "#111",
        colorBorderMiddle: "#888",
        colorBorderMiddleEnd: "#555",
        colorBorderInner: "#111",

        colorNeedleShadowDown: "#550",
        colorNeedleCircleOuter: "#333",
        colorNeedleCircleOuterEnd: "#111",
        class: "gauge"
      };
    }
    else if (type == 3) {
      this._gu_options =
      {
        units: "Fuel",
        width: "150",
        height: "150",
        minValue: "0",
        maxValue: "100",
        startAngle: "120",
        ticksAngle: "120",
        majorTicks: ["E", "", "F"],
        minorTicks: 2,
        strokeTicks: false,
        highlights: [
          { "from": 0, "to": 15, "color": "rgba(200, 10, 10, .5)" },
          { "from": 15, "to": 35, "color": "rgba(200, 200, 50, .5)" },
          { "from": 80, "to": 100, "color": "rgba(50, 200, 50, .3)" }
        ],
        highlightsWidth: 25,
        numbersMargin: 5,

        colorPlate: "rgb(255,255,255)",

        valueBox: "false",

        borderShadowWidth: "0",
        borders: "false",
        needleType: "arrow",
        needleWidth: "2",
        needleCircleSize: "7",
        needleCircleOuter: "true",
        needleCircleInner: "false",

        borderInnerWidth: "0",
        borderMiddleWidth: "0",
        borderOuterWidth: "5",
        colorBorderOuter: "#000",
        colorBorderOuterEnd: "#555",
        colorNeedleShadowDown: "#222",

        fontNumbersSize: "50",
        fontUnitsSize: "50",

        animationRule: "linear",
        animationDuration: "1000",
        class: "gauge"
      };
    }
    this._rg_canvas = document.createElement("canvas");
    this._radial_gauge = new RadialGauge(Object.assign(this._gu_options, { renderTo: this._rg_canvas }));
    this._radial_gauge.value = source;
    this._canvas_texture = Texture.from(this._rg_canvas);
    this._radial_gauge.draw();
    // this.texture = this._canvas_texture;
    this._cell = new Sprite(this._canvas_texture);
    this._cell.width = 150;
    this._cell.height = 150;
    // this.width = this._canvas_texture.width;
    // this.height = this._canvas_texture.height;
    this._cell.anchor.set(0.5, 0.5);
    this.anchor.set(0.5, 0.5);
    this.addChild(this._cell);
    this.addChild(this._graphics);


    this._temp_status.texture_width = 150;// this._canvas_texture.width;
    this._temp_status.texture_height = 150;// this._canvas_texture.height;

    this._temp_status.texture_helf_width = 75;// this._canvas_texture.width / 2;
    this._temp_status.texture_helf_height = 75;//this._canvas_texture.height / 2;

    this._temp_status.spx = -this._temp_status.texture_width;
    this._temp_status.spy = -this._temp_status.texture_height;

    this._temp_status.epx = this._temp_status.texture_width;
    this._temp_status.epy = this._temp_status.texture_height;

  }

  public update(value?: number) {
    this._graphics.clear();
    this._graphics.lineStyle(1, 0x0000FF, 1);
    if (this._bActivated) {
      this._graphics.beginFill(0xFFFFFF);
      this._graphics.drawCircle(this._temp_status.spx, this._temp_status.spy, 10);
      this._graphics.endFill();

      this._graphics.beginFill(0xFFFFFF);
      this._graphics.drawCircle(this._temp_status.epx, this._temp_status.spy, 10);
      this._graphics.endFill();

      this._graphics.beginFill(0xFFFFFF);
      this._graphics.drawCircle(this._temp_status.spx, this._temp_status.epy, 10);
      this._graphics.endFill();

      this._graphics.beginFill(0xFFFFFF);
      this._graphics.drawCircle(this._temp_status.epx, this._temp_status.epy, 10);
      this._graphics.endFill();
    }

    if (value) this._source = value;
    this._radial_gauge.value = this._source;
    this._canvas_texture.update();

  }

  private onPointerdown() {

    this._temp_status.width = this.width;
    this._temp_status.height = this.height;
    this._temp_status.alpha = this.alpha;

    this.width *= 1.1;
    this.height *= 1.1;
    this._cell.alpha = 0.6;

    this._bActivated = true;

    // this._main_app.stage.on('pointermove', (event: any) => { this.onDragMove(event, this._sprite) });
  }

  private onPointerup() {

    // if ( this._bActivated ){
    //   this.width = this._temp_status.width;
    //   this.height = this._temp_status.height;
    //   this._cell.alpha = this._temp_status.alpha;
    //   this._bActivated = false;
    //   } else {
    //     this._temp_status.width = this.width;
    //     this._temp_status.height = this.height;
    //     this._temp_status.alpha = this.alpha;

    //     this.width *= 1.1;
    //     this.height *= 1.1;
    //     this._cell.alpha = 0.6;

    //     this._bActivated = true;
    //   }


    this.width = this._temp_status.width;
    this.height = this._temp_status.height;
    this._cell.alpha = this._temp_status.alpha;
    this._bActivated = false;
  }
}
