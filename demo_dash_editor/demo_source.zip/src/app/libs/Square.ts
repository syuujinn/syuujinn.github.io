
  export interface View {
    width: number;
    height: number;
}

export interface Point {
    x: number;
    y: number;
    z?: number;
}

export  interface Rectangle {
    x: number;
    y: number;
    width: number;
    height: number;
}

export class Cell implements Rectangle {
    x: number;
    y: number;
    ex: number;
    ey: number;
    width: number;
    height: number;
    center: Point;


    constructor(rect: Rectangle) {
        this.x = rect.x || 0;
        this.y = rect.y || 0;
        this.height = rect.height || 0;
        this.width = rect.width || 0;
        this.ex = this.x + this.width;
        this.ey = this.y + this.height;
        this.center = { x: (this.x + this.width / 2), y: (this.y + this.height / 2) };

    }

    isInside(pos: Point): boolean {
        return pos.x >= this.x && pos.x <= this.ex && pos.y >= this.y && pos.y <= this.ey;
    }

    public clone(){
      return new Cell({ x: this.x, y: this.y, width: this.width, height: this.height });
    }

}

export class Square {

    range: Rectangle;
    split: number = 0;
    cells: Cell[] = [];
    ncx: number ;
    ncy: number ;
    ncz?: number ;
    first?: Cell;
    cw: number = 0;
    ch: number = 0;

    constructor(range: Rectangle, sx: number, sy: number, sz?: number) {
        this.range = range;
        this.ncx = sx;
        this.ncy = sy;
        this.ini();

    }

    isInside( p: Point ){ 
      
      return  p.x >= this.range.x && p.x <= ( this.range.width + this.range.x) && p.y >= this.range.y && p.y <= ( this.range.height + this.range.y );

    }


    getCell(col: number, row: number = 0 ): Cell {
        if (arguments.length === 1){
            return this.cells[col]; } else {
            return this.cells[col + row * this.ncx]; }
    }

    getCellByPosition(x: number = 0, y: number = 0 ) {
      var c;
      for ( var index = 0; index< this.cells.length; index++) {
        if ( this.cells[index].isInside({x,y})){
          c =  this.cells[index];
          break;
        }
      }
      return c;
    }

    getIndexByPosition(x: number = 0, y: number = 0){
      var c = -1;
      for ( var index = 0; index< this.cells.length; index++) {
        if ( this.cells[index].isInside( {x,y})){
          c =  index;
          break;
        }
      }
      return c;
    }



    ini() {

        /*
            -------------
            | 0 | 1 | 2 |
            -------------
            | 3 | 4 | 5 |
            -------------
        */

        const sx = this.range.x;
        const sy = this.range.y;
        const w = this.range.width / this.ncx;
        const h = this.range.height / this.ncy;

        this.cw = w;
        this.ch = h;

        for ( let iy = 0; iy < this.ncy; iy++) {
            for (let ix = 0; ix < this.ncx; ix++) {
                const t: Cell = new Cell({ x: ix * w + sx, y: iy * h + sy, width: w, height: h });
                this.cells.push(t);
            }
        }
        this.first = this.cells[0];

    }
}
