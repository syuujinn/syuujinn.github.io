import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { MyMessageService, GlobalShotcutkey } from "../app/Message.service";
import { HotkeysService, Hotkey } from 'angular2-hotkeys';

import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'editor';
  private _toolbarItems: MenuItem[] = [];

  public get toolbarItems(): MenuItem[] { return this._toolbarItems; }
  public set toolbarItems(val: MenuItem[]) { this._toolbarItems = val; }

  constructor(private _myMessageService: MyMessageService, private _hotkeysService: HotkeysService, private _translateService: TranslateService) {

    if (localStorage && !( "lang" in localStorage)){
      localStorage["lang"] = "tw";
    }

    let keys = Object.keys(GlobalShotcutkey);
    for (let i = 0; i < keys.length; i++) {
      let key = keys[i]; // GlobalShotcutkey[i];
      let skey = GlobalShotcutkey[key];

      this._hotkeysService.add(new Hotkey(skey, (event: KeyboardEvent): boolean => {
        this.title = `you keydown event =>${ key }`;
        this._myMessageService.onMenuStateChange(key);
        return false; // Prevent bubbling
      }));
    }

    this._toolbarItems = [
      {
        label: 'File',
        items: [{
          label: 'New',
          icon: 'pi pi-fw pi-plus',
          items: [
            { label: 'Project' },
            { label: 'Other' },
          ]
        },
        { label: 'Open' },
        { label: 'Quit' }
        ]
      },
      {
        label: 'Edit',
        icon: 'pi pi-fw pi-pencil',
        items: [
          { label: 'Delete', icon: 'pi pi-fw pi-trash' },
          { label: 'Refresh', icon: 'pi pi-fw pi-refresh' }
        ]
      }
    ];
  }

  ngOnInit(): void {
    
    this._translateService.setDefaultLang( localStorage["lang"]);
    this._translateService.onLangChange.subscribe(()=>
    { 
      this.setlangOption();
    });
    this.setlangOption();
  }

  private setlangOption(){
    this._translateService.get(['file'])
    .subscribe(translations => {
     this._toolbarItems = [
       {
         label: translations['file'],
         command: () => { 
           if ( localStorage["lang"] == "tw") {
             localStorage["lang"] = "en";
           } else {
             localStorage["lang"] = "tw";
           }

           this._translateService.use( localStorage["lang"]);
         }
       },
       {
         label: 'Edit',
         icon: 'pi pi-fw pi-pencil',
         items: [
           { label: 'Delete', icon: 'pi pi-fw pi-trash' },
           { label: 'Refresh', icon: 'pi pi-fw pi-refresh' }
         ]
       }
     ];
    });
  }


}

